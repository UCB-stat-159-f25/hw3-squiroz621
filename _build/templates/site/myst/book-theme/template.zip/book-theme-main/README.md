# Book Theme

> [!NOTE]
> This repository contains the _build artifacts_ for the MyST Book Theme, it is not meant for editing by humans.
> - Source code exists at [`github.com/jupyter-book/myst-theme`](https://github.com/jupyter-book/myst-theme). Make edits there, not here.
> - To report an bug or request a feature, use the [`github.com/jupyter-book/myst-theme/issues`](https://github.com/executablebooks/myst-theme/issues).
